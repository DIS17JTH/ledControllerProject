package se.ju.students.malu1798.ledcontrollerproject;

import android.widget.TextView;

public class ViewHolder {
    public TextView textView;

}
